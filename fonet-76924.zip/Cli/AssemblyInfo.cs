using System.Reflection;
#if DEBUG
[assembly: AssemblyTitle("FO.NET CLI (Debug)")]
[assembly: AssemblyConfiguration("Debug")]
#else
[assembly: AssemblyTitle("FO.NET CLI")]
[assembly: AssemblyConfiguration("Release")]
#endif
[assembly: AssemblyDescription("Command line interface to FO.NET")]
[assembly: AssemblyProduct("FO.NET")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0.*")]
