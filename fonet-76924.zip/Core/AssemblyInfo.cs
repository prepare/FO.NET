using System.Reflection;
#if DEBUG
[assembly: AssemblyTitle("FO.NET (Debug)")]
[assembly: AssemblyConfiguration("Debug")]
#else
[assembly: AssemblyTitle("FO.NET")]
[assembly: AssemblyConfiguration("Release")]
#endif
[assembly: AssemblyDescription("XSL-FO to PDF Rendering Engine")]
[assembly: AssemblyProduct("FO.NET")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0.*")]
