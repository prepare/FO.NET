namespace Fonet.Fo.Properties
{
    internal class BorderStartWidth
    {
        internal class Conditionality : GenericCondBorderWidth.Enums.Conditionality { }

    }
}