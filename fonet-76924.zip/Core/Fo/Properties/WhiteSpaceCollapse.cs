namespace Fonet.Fo.Properties
{
    internal class WhiteSpaceCollapse : GenericBoolean.Enums { }
}