namespace Fonet.Fo.Properties
{
    internal class BreakBefore
        : GenericBreak.Enums { }
}