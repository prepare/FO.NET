namespace Fonet.Fo.Properties
{
    internal class BorderLeftStyle
        : GenericBorderStyle.Enums { }
}