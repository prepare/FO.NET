namespace Fonet.Fo.Properties
{
    internal class Hyphenate
    {
        public const int TRUE = Constants.TRUE;

        public const int FALSE = Constants.FALSE;

    }
}