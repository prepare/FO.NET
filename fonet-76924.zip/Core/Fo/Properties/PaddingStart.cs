namespace Fonet.Fo.Properties
{
    internal class PaddingStart
    {
        internal class Conditionality : GenericCondLength.Enums.Conditionality { }

    }
}