namespace Fonet.Fo.Properties
{
    internal class Span
    {
        public const int NONE = Constants.NONE;

        public const int ALL = Constants.ALL;

    }
}