namespace Fonet.Fo.Properties
{
    internal class TableLayout
    {
        public const int AUTO = Constants.AUTO;

        public const int FIXED = Constants.FIXED;

    }
}