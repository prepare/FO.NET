namespace Fonet.Fo.Properties
{
    internal class RuleStyle
    {
        public const int NONE = Constants.NONE;

        public const int DOTTED = Constants.DOTTED;

        public const int DASHED = Constants.DASHED;

        public const int SOLID = Constants.SOLID;

        public const int DOUBLE = Constants.DOUBLE;

        public const int GROOVE = Constants.GROOVE;

        public const int RIDGE = Constants.RIDGE;

    }
}