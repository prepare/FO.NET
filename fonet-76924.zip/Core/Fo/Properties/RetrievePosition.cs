namespace Fonet.Fo.Properties
{
    internal class RetrievePosition
    {
        public const int FSWP = Constants.FSWP;

        public const int FIC = Constants.FIC;

        public const int LSWP = Constants.LSWP;

        public const int LEWP = Constants.LEWP;

    }
}