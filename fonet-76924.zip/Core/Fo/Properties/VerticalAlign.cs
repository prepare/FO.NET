namespace Fonet.Fo.Properties
{
    internal class VerticalAlign
    {
        public const int BASELINE = Constants.BASELINE;

        public const int MIDDLE = Constants.MIDDLE;

        public const int SUB = Constants.SUB;

        public const int SUPER = Constants.SUPER;

        public const int TEXT_TOP = Constants.TEXT_TOP;

        public const int TEXT_BOTTOM = Constants.TEXT_BOTTOM;

        public const int TOP = Constants.TOP;

        public const int BOTTOM = Constants.BOTTOM;

    }
}