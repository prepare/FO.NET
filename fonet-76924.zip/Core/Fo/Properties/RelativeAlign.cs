namespace Fonet.Fo.Properties
{
    internal class RelativeAlign
    {
        public const int BEFORE = Constants.BEFORE;

        public const int BASELINE = Constants.BASELINE;

    }
}