namespace Fonet.Fo.Properties
{
    internal class BorderCollapse
    {
        public const int SEPARATE = Constants.SEPARATE;

        public const int COLLAPSE = Constants.COLLAPSE;

    }
}