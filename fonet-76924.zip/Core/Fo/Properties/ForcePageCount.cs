namespace Fonet.Fo.Properties
{
    internal class ForcePageCount
    {
        public const int EVEN = Constants.EVEN;

        public const int ODD = Constants.ODD;

        public const int END_ON_EVEN = Constants.END_ON_EVEN;

        public const int END_ON_ODD = Constants.END_ON_ODD;

        public const int NO_FORCE = Constants.NO_FORCE;

        public const int AUTO = Constants.AUTO;

    }
}