namespace Fonet.Fo.Properties
{
    internal class BorderAfterStyle
        : GenericBorderStyle.Enums { }
}