namespace Fonet.Fo.Properties
{
    internal class PaddingAfter
    {
        internal class Conditionality : GenericCondLength.Enums.Conditionality { }

    }
}