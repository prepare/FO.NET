namespace Fonet.Fo.Properties
{
    internal class SpaceEnd
    {
        internal class Precedence : GenericSpace.Enums.Precedence { }

        internal class Conditionality : GenericSpace.Enums.Conditionality { }

    }
}