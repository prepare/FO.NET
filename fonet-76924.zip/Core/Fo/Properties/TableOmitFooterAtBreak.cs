namespace Fonet.Fo.Properties
{
    internal class TableOmitFooterAtBreak : GenericBoolean.Enums { }
}