namespace Fonet.Fo.Properties
{
    internal class BorderRightStyle
        : GenericBorderStyle.Enums { }
}