namespace Fonet.Fo.Properties
{
    internal class RetrieveBoundary
    {
        public const int PAGE = Constants.PAGE;

        public const int PAGE_SEQUENCE = Constants.PAGE_SEQUENCE;

        public const int DOCUMENT = Constants.DOCUMENT;

    }
}