namespace Fonet.Fo.Properties
{
    internal class PaddingEnd
    {
        internal class Conditionality : GenericCondLength.Enums.Conditionality { }

    }
}