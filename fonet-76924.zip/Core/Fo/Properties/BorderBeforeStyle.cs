namespace Fonet.Fo.Properties
{
    internal class BorderBeforeStyle
        : GenericBorderStyle.Enums { }
}