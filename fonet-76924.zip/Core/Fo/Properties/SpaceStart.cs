namespace Fonet.Fo.Properties
{
    internal class SpaceStart
    {
        internal class Precedence : GenericSpace.Enums.Precedence { }

        internal class Conditionality : GenericSpace.Enums.Conditionality { }

    }
}