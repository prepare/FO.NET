namespace Fonet.Fo.Properties
{
    internal class SpaceAfter
    {
        internal class Precedence : GenericSpace.Enums.Precedence { }

        internal class Conditionality : GenericSpace.Enums.Conditionality { }

    }
}