namespace Fonet.Fo.Properties
{
    internal class TextAlign
    {
        public const int CENTER = Constants.CENTER;

        public const int END = Constants.END;

        public const int START = Constants.START;

        public const int JUSTIFY = Constants.JUSTIFY;

    }
}