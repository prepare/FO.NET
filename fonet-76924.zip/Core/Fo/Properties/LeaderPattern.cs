namespace Fonet.Fo.Properties
{
    internal class LeaderPattern
    {
        public const int SPACE = Constants.SPACE;

        public const int RULE = Constants.RULE;

        public const int DOTS = Constants.DOTS;

        public const int USECONTENT = Constants.USECONTENT;

    }
}