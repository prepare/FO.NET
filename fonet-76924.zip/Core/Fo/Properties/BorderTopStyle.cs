namespace Fonet.Fo.Properties
{
    internal class BorderTopStyle
        : GenericBorderStyle.Enums { }
}