namespace Fonet.Fo.Properties
{
    internal class Precedence
    {
        public const int TRUE = Constants.TRUE;

        public const int FALSE = Constants.FALSE;

    }
}