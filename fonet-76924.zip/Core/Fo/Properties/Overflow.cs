namespace Fonet.Fo.Properties
{
    internal class Overflow
    {
        public const int VISIBLE = Constants.VISIBLE;

        public const int HIDDEN = Constants.HIDDEN;

        public const int SCROLL = Constants.SCROLL;

        public const int AUTO = Constants.AUTO;

    }
}