namespace Fonet.Fo.Properties
{
    internal class BreakAfter
        : GenericBreak.Enums { }
}