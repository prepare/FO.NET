namespace Fonet.Layout
{
    internal class HyphenationProps
    {
        public int hyphenate;

        public char hyphenationChar;

        public int hyphenationPushCharacterCount;

        public int hyphenationRemainCharacterCount;

        public string language;

        public string country;

        public HyphenationProps()
        {
        }

    }
}