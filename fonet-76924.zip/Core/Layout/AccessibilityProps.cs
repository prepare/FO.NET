namespace Fonet.Layout
{
    internal class AccessibilityProps
    {
        public string sourceDoc = null;

        public string role = null;

        public AccessibilityProps()
        {
        }
    }
}